var getParams = function (url) {
    var params = {};
    var parser = document.createElement('a');
    parser.href = url;
    var query = parser.search.substring(1);
    var vars = query.split('&');
    for (var i = 0; i < vars.length; i++) {
      var pair = vars[i].split('=');
      params[pair[0]] = decodeURIComponent(pair[1]);
    }
    return params;
  };

    // ---  START EVENTBRITE IFRAME -----
    params = getParams(window.location.href);
    var eventId = params.eid;

    document.getElementById("loading").innerHTML = 'Loading event: ' + eventId;
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: eventId,
        iframeContainerId: 'eventbrite-widget-container-50019077407',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
    // --- END EVENTBRITE IFRAME -----
